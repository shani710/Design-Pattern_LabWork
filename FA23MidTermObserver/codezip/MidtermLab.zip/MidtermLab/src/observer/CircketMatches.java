/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package observer;

/**
 *
 * @author fa20-bse-053
 */
import java.util.ArrayList;
import java.util.List;

public class CircketMatches {
	
   private List<LiveMatches> liveMatches = new ArrayList<LiveMatches>();
   private int state;
   private int score;

   public int getState() {
      return state ;
      
   }

   public void setState(int state, int score) {
      this.state = state;
      this.score = score;
      notify();
   }

   public void attach(LiveMatches liveMatches){
     liveMatches.add(liveMatches);		
   }

   @Override
   public void notify(){
      for (LiveMatches observer : liveMatches) {
         observer.update();
      }
   } 	
}